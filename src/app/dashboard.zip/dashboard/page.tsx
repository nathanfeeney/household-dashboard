import { headers } from "next/headers";
import { auth } from "@/lib/auth";
import { redirect } from "next/navigation";
import { getHousehold } from "@/app/actions/household";
import WelcomeMessage from "@/components/WelcomeMessage";
import { DashboardGrid } from "@/components/DashboardGrid";
import DateTime from "@/components/DateTime";

export default async function DashboardPage() {
  const session = await auth.api.getSession({
    headers: await headers(),
  });

  if (!session) redirect("/sign-in");

  const household = await getHousehold();
  if (!household) redirect("/household");

  return (
    <div style={{ padding: "1rem" }}>
        <WelcomeMessage />
        <DateTime />
        <DashboardGrid />
    </div>
  );
}